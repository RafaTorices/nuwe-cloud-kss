import json
import boto3
import os

s3 = boto3.client('s3')
sns = boto3.client('sns')

bucket_name = 'datastorage'
topic_arn = os.environ['TOPIC_ARN']

def lambda_handler(event, context):
    for record in event['Records']:
        try:
            payload = json.loads(record['kinesis']['data'])
            payload['test'] = True

            event_id = record['eventID']
            file_name = f"{event_id}.json"

            s3.put_object(
                Bucket=bucket_name,
                Key=file_name,
                Body=json.dumps(payload)
            )

        except Exception as e:
            error_message = {
                "error": str(e),
                "record": record
            }
            sns.publish(
                TopicArn=topic_arn,
                Message=json.dumps(error_message)
            )
